import xdrlib

xdrlib._test()
